.. include:: ../Includes.txt



.. _installation:

============
Installation
============

Target group: **Administrators**

- How is the extension installed?
- Are there any dependencies that need to be resolved?

You can also refer to general TYPO3 documentation, for example the
:ref:`t3install:start`.
