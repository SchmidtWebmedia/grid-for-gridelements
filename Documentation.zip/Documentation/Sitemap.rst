:template: sitemap.html

.. _sitemap:

=======
Sitemap
=======

.. template 'sitemap.html' will insert the toctree as a sitemap here
below normal contents
